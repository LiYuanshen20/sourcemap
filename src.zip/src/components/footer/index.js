import React, { Component } from 'react';
import './index.scss'
class App extends Component {
  constructor(props) {
    super(props);
  }
  state = {  }
  render() { 
    return (
      <div className='my_footer'>蓝鸽科技 版权所有</div>
    );
  }
}
 
export default App;